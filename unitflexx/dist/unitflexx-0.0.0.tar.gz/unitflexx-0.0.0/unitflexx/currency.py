def convert_currency(from_unit: str, to_unit: str, value: float) -> float:
    rate = 0.9  # USD to EUR
    if from_unit == "usd" and to_unit == "eur":
        return round(value * rate, 4)
    elif from_unit == "eur" and to_unit == "usd":
        return round(value / rate, 4)
    raise ValueError(f"Unsupported currency pair: {from_unit} to {to_unit}")